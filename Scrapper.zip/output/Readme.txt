1. Enter a list of keywords in "keywords.txt" file

2. Double Click on "TheScrapper.exe"

3. Check "output" folder for the scrapped data of each site 